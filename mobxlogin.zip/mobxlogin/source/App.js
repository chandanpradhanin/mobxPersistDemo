import React, { Component } from 'react';
import { View } from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import StoreManager from './storeManager';
import { createStores } from './store';
import { create } from 'mobx-persist';

import Modules from '@modules';
import { observer, Provider } from 'mobx-react';
import Routes from '@src/routes';


const storeManager = new StoreManager(createStores());
const hydrate = create({ storage: AsyncStorage });
Modules.forEach(module => module({ storeManager, options: { hydrate } }));

@observer
export default class App extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <Provider {...storeManager.stores} >
        <Routes />
      </Provider>
    );
  }
}
