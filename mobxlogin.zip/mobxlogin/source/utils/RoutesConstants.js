export default {
  ROOT: 'root',
  LOGIN:'login',
  HOME_STACK: 'homeStack',
  HOME: 'home',
  
};
