import React, { Component } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { inject, observer } from 'mobx-react';
import { Actions } from 'react-native-router-flux';
import styles from './styles';

@inject('authStore')

@observer
export default class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  onLogoutPress = () => {
    const { authStore } = this.props
    authStore.setData('', '', '');
    Actions.login()
  }

  render() {
    const { authStore } = this.props
    return (
      <View style={styles.container}>
        <Text style={styles.topTitle}>Welcome {authStore.fullName} </Text>
        <Text style={styles.subTitle}>Your name contains {authStore.getUserNameLength} characters (used computed and _. size())</Text>
        <TouchableOpacity style={styles.ButtonContainer} onPress={this.onLogoutPress}>
          <Text style={styles.ButtonText}>{"Logout"}</Text>
        </TouchableOpacity>
      </View>
    );
  }
}
