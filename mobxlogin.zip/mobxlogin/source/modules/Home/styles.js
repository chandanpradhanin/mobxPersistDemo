import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    container : {
        flex:1, 
        paddingHorizontal:20
    },
    topTitle : {
        width:'100%', 
        marginTop:40, 
        fontSize:30
    },
    subTitle : {
        width:'100%', 
        fontSize:15
    },
    ButtonContainer : {
        width:'100%', 
        height:40, 
        marginTop:50, 
        backgroundColor:'blue', 
        justifyContent:'center', 
        alignItems:'center'
    },
    ButtonText : {
        width:'100%', 
        textAlign:'center', 
        color:'white'
    } 
})

export default styles;