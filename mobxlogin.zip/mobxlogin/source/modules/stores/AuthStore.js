import React from "react";
import { observable, action, computed, makeObservable } from "mobx";
import _ from 'lodash';
import { persist } from 'mobx-persist';

export default class AuthStore {

  @persist @observable userName = "";
  @persist @observable password = "";
  @persist @observable fullName = "";
  @persist @observable isLogggedIn = false;


  constructor() {
    makeObservable(this);
  }

  @action setData(fullName, userName, password) {
    if (fullName == '' && userName == '' && password == '') {
      this.isLogggedIn = false
    }
    else {
      this.isLogggedIn = true
    }

    this.fullName = fullName;
    this.userName = userName;
    this.password = password;
  }

  // @computed getUserNameLength(){
  //   // alert(_.size(this.fullName))
  //     return '5';
  // }

  @computed get getUserNameLength() {
    return _.size(this.fullName);
}
}
