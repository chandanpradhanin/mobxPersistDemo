import auth from '@auth';

const Modules = [auth];

export default Modules;