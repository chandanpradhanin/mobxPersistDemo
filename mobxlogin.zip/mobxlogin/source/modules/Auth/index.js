// import SplashScreen from 'react-native-splash-screen';
import RoutesConstants from '@utils/RoutesConstants';
import { goto } from '@utils/actions';

const init = async ({ storeManager, options }) => {
  const {
    authStore,
    // authStore,
  } = storeManager.stores;
  const { hydrate } = options;

  hydrate('authStore', authStore).then(() => {
    setTimeout(() => {
      if(authStore.isLogggedIn === true){
        goto(RoutesConstants.HOME_STACK)
      }
      else {
        // goto(RoutesConstants.LOGIN)
      }
      // SplashScreen.hide();
    }, 100);
  });
};

export default init;
