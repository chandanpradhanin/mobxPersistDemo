import React, { Component } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert } from 'react-native';
import { inject, observer } from 'mobx-react';
import { makeObservable, observable, autorun } from 'mobx';
import {Actions} from 'react-native-router-flux';
import styles from './styles';

@inject('authStore')

@observer
export default class Login extends Component {

  @observable fullName = '';
  @observable userId = '';
  @observable password = '';

  constructor(props) {
    super(props);
    makeObservable(this);

    autorun(() => {
      // alert('Autorun called');
    } );
  }


  

  onLoginPress = () => {
    if(this.fullName == '' || this.userId == '' || this.password == ''){
      Alert.alert('Validation','All fields are mandatory');
    }
    else{
      const { authStore } = this.props
      authStore.setData(this.fullName ,this.userId, this.password)
      Actions.homeStack()
    } 
  }

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.topTitle}> Login Here ... </Text>

        <TextInput
          placeholder="Full name"
          placeholderTextColor="green"
          style={styles.commonTextInput}
          onChangeText={(text) => { this.fullName = text }}
          value={this.fullName}
        />

        <TextInput
          placeholder="email"
          placeholderTextColor="green"
          style={styles.commonTextInput}
          onChangeText={(text) => { this.userId = text }}
          value={this.userId}
          keyboardType={'email-address'}
        />

        <TextInput
          placeholder="Password"
          placeholderTextColor="green"
          style={styles.commonTextInput}
          onChangeText={(text) => { this.password = text }}
          value={this.password}
          secureTextEntry={true}
        />

        <TouchableOpacity
          onPress={this.onLoginPress}
          style={styles.loginButtonContainer}>
          <Text style={styles.loginBUttonText}>{'Login'}</Text>
        </TouchableOpacity>
      </View>
    );
  }
}
