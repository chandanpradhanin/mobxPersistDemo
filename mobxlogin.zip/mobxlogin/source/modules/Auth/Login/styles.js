import { StyleSheet } from 'react-native';


const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 50,
        paddingHorizontal: 20,
    },
    topTitle :{
        width:'100%',
        marginTop:50,
        fontSize:30,
    },  
    commonTextInput: {
        height: 30,
        borderColor: 'gray',
        borderWidth: 1,
        marginTop: 10,
        paddingLeft: 5
    },
    loginButtonContainer: {
        height: 40,
        backgroundColor: 'blue',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20
    },
    loginBUttonText : { 
        color: 'white' 
    }
})

export default styles;